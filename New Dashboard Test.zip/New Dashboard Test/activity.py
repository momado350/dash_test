#https://medium.com/innovation-res/how-to-build-an-app-using-dash-plotly-and-python-and-deploy-it-to-aws-5d8d2c7bd652
##http://patronActivitydash-env.eba-zv5vrzxh.us-east-2.elasticbeanstalk.com/
#https://www.youtube.com/watch?v=BeOKTpFsuvk

import dash
from dash import html
import dash_html_components as html
from dash import dcc
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import pandas as pd
# import dash_auth
# from users import USERNAME_PASSWORD_PAIRS
from app import app

mer_df = pd.read_csv('only 2023.csv',parse_dates=['Trans Hist Date'])
#mer_df = mer_df[mer_df['Trans Hist Date'] <= '2023-03-24']

activity = mer_df.groupby(['Trans Hist Date'])[['patrons', 'SessionID', 'total']].sum().reset_index()
activityw = mer_df.groupby([pd.Grouper(key='Trans Hist Date', freq='W-SAT',label='left',closed='left')])[['patrons', 'SessionID', 'total']].sum().reset_index()
activitym = mer_df.groupby([pd.Grouper(key='Trans Hist Date', freq='M')])[['patrons', 'SessionID', 'total']].sum().reset_index()


layout = html.Div([
    
    html.Div([
        html.Div([
            
        ], className='one-third column'),

        html.Div([
            html.Div([
                html.H3('Patrons Activity Dashboard', style={'margin-bottom': '0px', 'color': 'white'}),
                html.H5('Track Patron Activity by Library Branch', style={'margin-bottom': '0px', 'color': 'white'})
            ])

        ], className='one-half column', id = 'title'),

        html.Div([
            html.H6('Last Updated: ' + str(mer_df['Trans Hist Date'].iloc[-1].strftime('%B %d, %Y')) + ' 00:01 (UTC)',
                    style={'color': 'orange'})

        ], className='one-third column', id = 'title1'),

        html.Div([
            html.P('Select Year', className='fix_label', style= {'color': 'white'}),
            dcc.Slider(id = 'select_years',
                       included=False,
                       updatemode='drag',
                       tooltip={'always_visible': True},
                       min = 2022,
                       max = 2023,
                       step = 1,
                       value=2023,
                       marks={str(yr): str(yr) for yr in range(2022, 2023)},
                       className='dcc_compon'),

        ], className='one-half column', id = 'title2'),

    

        ###

    ], id = 'header', className= 'row flex-display', style={'margin-bottom': '25px'}),

    html.Div([
        html.Div([
            html.H6(children='Last Month Activity',
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{activitym['total'].iloc[-1]:,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('Month Before: ' + f"{activitym['total'].iloc[-3]:,.0f}"
                   + ' (' + str(round(((activitym['total'].iloc[-2] - activitym['total'].iloc[-3]) /
                                   activitym['total'].iloc[-3]) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})

        ], className='card_container three columns'),

html.Div([
            html.H6(children="Total Activity Last Week",
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{activityw['Trans Hist Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{activityw['total'].iloc[-2]:,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('Week Before: ' + f"{activityw['total'].iloc[-3]:,.0f}"
                   + ' (' + str(round(((activityw['total'].iloc[-2]-activityw['total'].iloc[-3]) /
                                   activityw['total'].iloc[-3]) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})

        ], className='card_container three columns'),

html.Div([
            html.H6(children="Patrons used computer Last Week",
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{activityw['Trans Hist Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{activityw['SessionID'].iloc[-2]:,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('Week Before: ' + f"{activityw['SessionID'].iloc[-3]:,.0f}"
                   + ' (' + str(round(((activityw['SessionID'].iloc[-2]-activityw['SessionID'].iloc[-3]) /
                                   activityw['SessionID'].iloc[-3]) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})

        ], className='card_container three columns'),

html.Div([
            html.H6(children="patrons checkedout items Last Week",
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{activityw['Trans Hist Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{activityw['patrons'].iloc[-2]:,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('Week Before: ' + f"{activityw['patrons'].iloc[-3]:,.0f}"
                   + ' (' + str(round(((activityw['patrons'].iloc[-2]-activityw['patrons'].iloc[-3]) /
                                   activityw['patrons'].iloc[-3]) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})

        ], className='card_container three columns'),

    ], className='row flex display'),
    html.Div([
        html.Div([
            html.P('Select Branch:', className='fix_label', style={'color': 'white'}),
            dcc.Dropdown(id = 'w_countries',
                         multi = False,
                         searchable= True,
                         value='KC-PLAZA',
                         placeholder= 'Select Countries',
                         options= [{'label': c, 'value': c}
                                   for c in (mer_df['Station Library Checkout'].unique())], className='dcc_compon'),
            html.P('Branch Activity: ' + ' ' + str(activityw['Trans Hist Date'].iloc[-1].strftime('%B %d, %Y')),
                   className='fix_label', style={'text-align': 'center', 'color': 'white'}),
            dcc.Graph(id = 'kcpl_total', config={'displayModeBar': False}, className='dcc_compon',
                      style={'margin-top': '20px'}),
dcc.Graph(id = 'kcpl_circ', config={'displayModeBar': False}, className='dcc_compon',
                      style={'margin-top': '20px'}),
dcc.Graph(id = 'kcpl_comp', config={'displayModeBar': False}, className='dcc_compon',
                      style={'margin-top': '20px'}),
# dcc.Graph(id = 'active', config={'displayModeBar': False}, className='dcc_compon',
#                       style={'margin-top': '20px'})

        ], className='create_container three columns'),

        html.Div([
dcc.Graph(id = 'pie_chart', config={'displayModeBar': 'hover'}
                      )
        ], className='create_container four columns'),

html.Div([
dcc.Graph(id = 'line_chart', config={'displayModeBar': 'hover'}
                      )
        ], className='create_container five columns'),

    ], className='row flex-display'),

##########################################################################
    html.Div([
html.Div([
dcc.Graph(id = 'multiline_chart', config={'displayModeBar': 'hover'}
                      )
        ], className='create_container1 twelve columns')

    ], className='row flex-display'),
#### here is chromebook metrics --------------------------------------------------------------------
# html.Div([
#     html.Div([
#             html.P('Select Branch:', className='fix_label', style={'color': 'white'}),
#             dcc.Dropdown(id = 'w_countries1',
#                          multi = False,
#                          searchable= True,
#                          value='KC-PLAZA',
#                          placeholder= 'Select Countries',
#                          options= [{'label': c, 'value': c}
#                                    for c in (circulationjcb['Trans Stat Station Library'].unique())], className='dcc_compon'),
#             html.P('Chromebooks as of: ' + ' ' + str(circulationjcb_2['Trans Stat Date'].iloc[-1].strftime('%B %d, %Y')),
#                    className='fix_label', style={'text-align': 'center', 'color': 'white'}),
#             dcc.Graph(id = 'kcpl_total1', config={'displayModeBar': False}, className='dcc_compon',
#                       style={'margin-top': '20px'}),
# dcc.Graph(id = 'kcpl_circ1', config={'displayModeBar': False}, className='dcc_compon',
#                       style={'margin-top': '20px'}),
# dcc.Graph(id = 'kcpl_comp1', config={'displayModeBar': False}, className='dcc_compon',
#                       style={'margin-top': '20px'}),
# # dcc.Graph(id = 'active', config={'displayModeBar': False}, className='dcc_compon',
# #                       style={'margin-top': '20px'})

#         ], className='create_container three columns'),
# html.Div([
# dcc.Graph(id = 'multiline_chart1', config={'displayModeBar': 'hover'}
#                       )
#         ], className='create_container1 twelve columns')

#     ], className='row flex-display')
    ##chromebooks metrics ends------------------------------------------------------------------
###########################################################

], id = 'mainContainer', style={'display': 'flex', 'flex-direction': 'column'})


@app.callback(Output('kcpl_total', 'figure'),
              [Input('w_countries','value')],
              [Input('select_years','value')])
def update_kcpl_total(w_countries, select_years):
    mer_df_2 = mer_df.groupby(['Station Library Checkout','year', pd.Grouper(key='Trans Hist Date', freq='W-SAT',label='left',closed='left')])[['patrons', 'SessionID', 'total']].sum().reset_index()
    value_kcpl_total = mer_df_2[mer_df_2['Station Library Checkout'] == w_countries]['total'].iloc[-2]
    delta_kcpl_total = mer_df_2[mer_df_2['Station Library Checkout'] == w_countries]['total'].iloc[-3]

    return {
        'data': [go.Indicator(
               mode='number+delta',
               value=value_kcpl_total,
               delta = {'reference': delta_kcpl_total,
                        'position': 'right',
                        'valueformat': ',i',
                        'relative': False,
                        'font': {'size': 15}},
               number={'valueformat': ',',
                       'font': {'size': 20}},
               domain={'y': [0, 1], 'x': [0, 1]}
        )],

        'layout': go.Layout(
            title={'text': 'Last Week Total',
                   'y': 1,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            font=dict(color='orange'),
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            height = 50,

        )
    }

@app.callback(Output('kcpl_circ', 'figure'),
              [Input('w_countries','value')],
              [Input('select_years','value')])
def update_kcpl_total(w_countries, select_years):
    covid_data_2 = mer_df.groupby(['Station Library Checkout', 'year', pd.Grouper(key='Trans Hist Date', freq='W-SAT',label='left',closed='left')])[['patrons', 'SessionID', 'total']].sum().reset_index()
    value_kcpl_circ = covid_data_2[covid_data_2['Station Library Checkout'] == w_countries]['SessionID'].iloc[-2]
    delta_kcpl_circ = covid_data_2[covid_data_2['Station Library Checkout'] == w_countries]['SessionID'].iloc[-3]

    return {
        'data': [go.Indicator(
               mode='number+delta',
               value=value_kcpl_circ,
               delta = {'reference': delta_kcpl_circ,
                        'position': 'right',
                        'valueformat': ',i',
                        'relative': False,
                        'font': {'size': 15}},
               number={'valueformat': ',',
                       'font': {'size': 20}},
               domain={'y': [0, 1], 'x': [0, 1]}
        )],

        'layout': go.Layout(
            title={'text': 'Patrons used computer Last Week',
                   'y': 1,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            font=dict(color='orange'),
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            height = 50,

        )
    }


@app.callback(Output('kcpl_comp', 'figure'),
              [Input('w_countries','value')],
              [Input('select_years','value')])
def update_kcpl_total(w_countries, select_years):
    covid_data_2 = mer_df.groupby(['Station Library Checkout', 'year', pd.Grouper(key='Trans Hist Date', freq='W-SAT',label='left',closed='left')])[['patrons', 'SessionID', 'total']].sum().reset_index()
    value_kcpl_comp = covid_data_2[covid_data_2['Station Library Checkout'] == w_countries]['patrons'].iloc[-2]
    delta_kcpl_comp = covid_data_2[covid_data_2['Station Library Checkout'] == w_countries]['patrons'].iloc[-3]

    return {
        'data': [go.Indicator(
               mode='number+delta',
               value=value_kcpl_comp,
               delta = {'reference': delta_kcpl_comp,
                        'position': 'right',
                        'valueformat': ',i',
                        'relative': False,
                        'font': {'size': 15}},
               number={'valueformat': ',',
                       'font': {'size': 20}},
               domain={'y': [0, 1], 'x': [0, 1]}
        )],

        'layout': go.Layout(
            title={'text': 'patrons checkedout items Last Week',
                   'y': 1,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            font=dict(color='orange'),
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            height = 50,

        )
    }
    ########################################################################
    # Chromebooks metrics callback ------------------------------------------------------------------------
# @app.callback(Output('kcpl_total1', 'figure'),
#               [Input('w_countries1','value')],
#               [Input('select_years','value')])
# def update_kcpl_total(w_countries1,select_years):
#     circulationjcb_2 = circulationjcb.groupby(['Trans Stat Station Library','Trans Stat Itype','year', pd.Grouper(key='Trans Stat Date', freq='W-SAT',label='left',closed='left')])['Trans Stat Id'].count().reset_index()
#     circulationjcb_2 = circulationjcb_2[circulationjcb_2['Trans Stat Itype'] == 'EQ-ECFCB']
#     # cols = {'Trans Stat Date':'2022-01-03 00:00:00','Station Library Checkout':['KC-RUIZ'], 'Trans Stat Id':[0]}
#     # empty = pd.DataFrame(data=cols)
#     # circulationjcb_2 = empty.append(circulationjcb_2, ignore_index=False).drop_duplicates().reset_index().fillna(0)
#     value_kcpl_total1 = circulationjcb_2[circulationjcb_2['Trans Stat Station Library'] == w_countries1]['Trans Stat Id'].iloc[-1]
#     delta_kcpl_total1 = circulationjcb_2[circulationjcb_2['Trans Stat Station Library'] == w_countries1]['Trans Stat Id'].iloc[-2]

    
    


#     return {
#         'data': [go.Indicator(
#                mode='number+delta',
#                value=value_kcpl_total1,
#                delta = {'reference': delta_kcpl_total1,
#                         'position': 'right',
#                         'valueformat': ',g',
#                         'relative': False,
#                         'font': {'size': 15}},
#                number={'valueformat': ',',
#                        'font': {'size': 20}},
#                domain={'y': [0, 1], 'x': [0, 1]}
#         )],

#         'layout': go.Layout(
#             title={'text': 'Last Week Chromebooks',
#                    'y': 1,
#                    'x': 0.5,
#                    'xanchor': 'center',
#                    'yanchor': 'top'},
#             font=dict(color='orange'),
#             paper_bgcolor='#1f2c56',
#             plot_bgcolor='#1f2c56',
#             height = 50,

#         )
#     }

# @app.callback(Output('kcpl_circ1', 'figure'),
#               [Input('w_countries1','value')])
# def update_kcpl_total(w_countries1):
#     circulationjcb_2 = circulationjcb.groupby(['Trans Stat Station Library','Trans Stat Itype', pd.Grouper(key='Trans Stat Date', freq='1M',label='left',closed='left')])['Trans Stat Id'].count().reset_index()
#     circulationjcb_2 = circulationjcb_2[circulationjcb_2['Trans Stat Itype'] == 'EQ-ECFCB']
#     # cols = {'Trans Hist Date':'2022-01-03 00:00:00','Station Library Checkout':['KC-RUIZ'], 'Item Type Code':[0]}
#     # empty = pd.DataFrame(data=cols)
#     # circulationjcb_2 = empty.append(circulationjcb_2, ignore_index=False).drop_duplicates().reset_index().fillna(0)
#     value_kcpl_circ1 = circulationjcb_2[circulationjcb_2['Trans Stat Station Library'] == w_countries1]['Trans Stat Id'].iloc[-1]
#     delta_kcpl_circ1 = circulationjcb_2[circulationjcb_2['Trans Stat Station Library'] == w_countries1]['Trans Stat Id'].iloc[-2]

#     return {
#         'data': [go.Indicator(
#                mode='number+delta',
#                value=value_kcpl_circ1,
#                delta = {'reference': delta_kcpl_circ1,
#                         'position': 'right',
#                         'valueformat': ',g',
#                         'relative': False,
#                         'font': {'size': 15}},
#                number={'valueformat': ',',
#                        'font': {'size': 20}},
#                domain={'y': [0, 1], 'x': [0, 1]}
#         )],

#         'layout': go.Layout(
#             title={'text': 'Last Month Chromebooks',
#                    'y': 1,
#                    'x': 0.5,
#                    'xanchor': 'center',
#                    'yanchor': 'top'},
#             font=dict(color='orange'),
#             paper_bgcolor='#1f2c56',
#             plot_bgcolor='#1f2c56',
#             height = 50,

#         )
#     }

# @app.callback(Output('kcpl_comp1', 'figure'),
#               [Input('w_countries1','value')])
# def update_kcpl_total(w_countries1):
#     circulationjcb_2 = circulationjcb.groupby(['Trans Stat Station Library','Trans Stat Itype', pd.Grouper(key='Trans Stat Date', freq='1M',label='left',closed='left')])['Trans Stat Id'].count().reset_index()
#     circulationjcb_2 = circulationjcb_2[circulationjcb_2['Trans Stat Itype'] == 'EQ-ECFCB']
#     value_kcpl_comp1 = circulationjcb_2['Trans Stat Id'].sum()
    
#     # circulationjcb_2 = circulationjcb_2[circulationjcb_2['Station Library Checkout'] == w_countries1]['Item Type Code'].iloc[-1]
#     #delta_kcpl_comp1 = circulationjcb_2[circulationjcb_2['Station Library Checkout'] == w_countries1]['Item Type Code'].iloc[-2]

#     return {
#         'data': [go.Indicator(
#                mode='number+delta',
#                value=value_kcpl_comp1,
#             #    delta = {'reference': delta_kcpl_comp1,
#             #             'position': 'right',
#             #             'valueformat': ',g',
#             #             'relative': False,
#             #             'font': {'size': 15}},
#                number={'valueformat': ',',
#                        'font': {'size': 20}},
#                domain={'y': [0, 1], 'x': [0, 1]}
#         )],

#         'layout': go.Layout(
#             title={'text': 'Total Chromebook Checkouts',
#                    'y': 1,
#                    'x': 0.5,
#                    'xanchor': 'center',
#                    'yanchor': 'top'},
#             font=dict(color='orange'),
#             paper_bgcolor='#1f2c56',
#             plot_bgcolor='#1f2c56',
#             height = 50,

#         )
#     }

# chromebooks metrics ends



@app.callback(Output('pie_chart', 'figure'),
              [Input('w_countries','value')],
              [Input('select_years','value')])
def update_graph(w_countries,select_years):
    covid_data_2 = mer_df.groupby(['Station Library Checkout', 'Trans Hist Date', 'year'])[['patrons', 'SessionID', 'total']].sum().reset_index()
    kcpl_total_value = covid_data_2[(covid_data_2['Station Library Checkout'] == w_countries) & (covid_data_2['year'] == select_years)]['patrons'].sum()
    kcpl_circ_value = covid_data_2[(covid_data_2['Station Library Checkout'] == w_countries) & (covid_data_2['year'] == select_years)]['SessionID'].sum()
    kcpl_comp_value = covid_data_2[(covid_data_2['Station Library Checkout'] == w_countries) & (covid_data_2['year'] == select_years)]['total'].sum()
    #active_value = covid_data_2[covid_data_2['Station Library Checkout'] == w_countries]['active'].iloc[-1]
    colors = ['orange', 'blue']

    return {
        'data': [go.Pie(
            # labels=['Circulation', 'Computer', 'Total of Both'],
            labels=['patrons checkedout items Last Week', 'Patrons used computer Last Week'],
            values=[kcpl_total_value, kcpl_circ_value, kcpl_comp_value],
            marker=dict(colors=colors),
            hoverinfo='label+value+percent',
            textinfo='label+value',
            hole=.7,
            rotation=45,
            # insidetextorientation= 'radial'

        )],

        'layout': go.Layout(
            title={'text': 'Branch Total: ' + (w_countries),
                   'y': 0.93,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            titlefont={'color': 'white',
                       'size': 20},
            font=dict(family='sans-serif',
                      color='white',
                      size=12),
            hovermode='closest',
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            legend={'orientation': 'h',
                    'bgcolor': '#1f2c56',
                    'xanchor': 'center', 'x': 0.5, 'y': -0.7}


        )
    }

@app.callback(Output('line_chart', 'figure'),
              [Input('w_countries','value')],
              [Input('select_years','value')])
def update_graph(w_countries, select_years):
    covid_data_2 = mer_df.groupby(['Station Library Checkout','Trans Hist Date', 'year'])[['patrons', 'SessionID', 'total']].sum().reset_index()
    covid_data_21 = covid_data_2[(covid_data_2['Station Library Checkout'] == w_countries) & (covid_data_2['year'] == select_years)][['Station Library Checkout', 'Trans Hist Date', 'total']].reset_index()
    covid_data_21['daily kcpl_total'] = covid_data_21['total'].shift(0)
    covid_data_21['Rolling Ave.'] = covid_data_21['total'].rolling(window=7).mean()


    return {
        'data': [go.Bar(
            x=covid_data_21['Trans Hist Date'].tail(30),
            y=covid_data_21['daily kcpl_total'].tail(30),
            name='Daily Patron Activity',
            marker=dict(color='orange'),
            hoverinfo='text',
            hovertext=
            '<b>Date</b>: ' + covid_data_21['Trans Hist Date'].tail(30).astype(str) + '<br>' +
            '<b>Daily Activity Numbers</b>: ' + [f'{x:,.0f}' for x in covid_data_21['daily kcpl_total'].tail(30)] + '<br>' +
            '<b>Branch</b>: ' + covid_data_21['Station Library Checkout'].tail(30).astype(str) + '<br>'


        ),
            go.Scatter(
                x=covid_data_21['Trans Hist Date'].tail(30),
                y=covid_data_21['Rolling Ave.'].tail(30),
                mode='lines',
                name='Rolling Average of the last 7 days - daily Patron Activity',
                line=dict(width=3, color='#FF00FF'),
                hoverinfo='text',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['Trans Hist Date'].tail(30).astype(str) + '<br>' +
                '<b>Daily Activity</b>: ' + [f'{x:,.0f}' for x in covid_data_21['Rolling Ave.'].tail(30)] + '<br>'


            )],

        'layout': go.Layout(
            title={'text': 'Last 30 Days Daily Patron Activity: ' + (w_countries),
                   'y': 0.93,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            titlefont={'color': 'white',
                       'size': 20},
            font=dict(family='sans-serif',
                      color='white',
                      size=12),
            hovermode='closest',
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            legend={'orientation': 'h',
                    'bgcolor': '#1f2c56',
                    'xanchor': 'center', 'x': 0.5, 'y': -0.7},
            margin=dict(r=0),
            xaxis=dict(title='<b>Date</b>',
                       color = 'white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Aerial',
                           color='white',
                           size=12
                       )),
            yaxis=dict(title='<b>Daily Patron Activity</b>',
                       color='white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Aerial',
                           color='white',
                           size=12
                       )
                       )


        )
    }
# callback for multiline chart
@app.callback(Output('multiline_chart', 'figure'),
              [Input('w_countries','value')],
              [Input('select_years','value')])
def update_graph(w_countries,select_years):
    if select_years == 2022:
    
        covid_data_21 = mer_df.groupby(['Station Library Checkout','Trans Hist Date', 'hours', 'year'])['total'].sum().reset_index()
        covid_data_21 = covid_data_21[(covid_data_21['Station Library Checkout'] == w_countries) & (covid_data_21['year'] == select_years)][['Station Library Checkout', 'Trans Hist Date','hours', 'total']].reset_index()
        covid_data_21 = pd.pivot_table(covid_data_21, columns='hours', values='total', index='Trans Hist Date').fillna(0).round(decimals = 0)
        ##
        cols = {'date':'2022-06-30 00:00:00','1 PM':[0], '10 AM':[0], '11 AM':[0], '12 PM':[0], '2 PM':[0], '3 PM':[0], '4 PM':[0], '5 PM':[0],
            '6 PM':[0], '7 PM':[0], '8 PM':[0], '9 AM':[0]}
        empty = pd.DataFrame(data=cols).set_index("date")

        covid_data_21 = empty.append(covid_data_21, ignore_index=False).drop_duplicates().reset_index().fillna(0)
    else:
        covid_data_21 = mer_df.groupby(['Station Library Checkout','Trans Hist Date', 'hours', 'year'])['total'].sum().reset_index()
        covid_data_21 = covid_data_21[(covid_data_21['Station Library Checkout'] == w_countries) & (covid_data_21['year'] == select_years)][['Station Library Checkout', 'Trans Hist Date','hours', 'total']].reset_index()
        covid_data_21 = pd.pivot_table(covid_data_21, columns='hours', values='total', index='Trans Hist Date').fillna(0).round(decimals = 0)
        cols = {'date':'2023-01-03 00:00:00','1 PM':[0], '10 AM':[0], '11 AM':[0], '12 PM':[0], '2 PM':[0], '3 PM':[0], '4 PM':[0], '5 PM':[0],
            '6 PM':[0], '7 PM':[0], '8 PM':[0], '9 AM':[0]}
        empty = pd.DataFrame(data=cols).set_index("date")

        covid_data_21 = empty.append(covid_data_21, ignore_index=False).drop_duplicates().reset_index().fillna(0)

    ##
    #covid_data_211['daily kcpl_total'] = covid_data_211['total'].shift(1)
    #covid_data_21['Rolling Ave.'] = covid_data_21['total'].rolling(window=7).mean()
    


    return {
        'data': [go.Scatter(
            x=covid_data_21['index'],
            y=covid_data_21['9 AM'],
            name='9 AM',
            marker=dict(color='orange'),
            hoverinfo='text',
            visible='legendonly',
            hovertext=
            '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
            '<b>Daily Activity Numbers</b>: ' + [f'{x:,.0f}' for x in covid_data_21['9 AM']] + '<br>' 
            + '<b>Hour</b>: ' + '9 AM' + '<br>'


        ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['10 AM'],
                mode='lines',
                name='10 AM',
                line=dict(width=3, color='#FF00FF'),
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Activity</b>: ' + [f'{x:,.0f}' for x in covid_data_21['10 AM']] + '<br>' 
                + '<b>Hour</b>: ' + '10 AM' + '<br>'


            ),
                go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['11 AM'],
                mode='lines',
                name='11 AM',
                line=dict(width=3, color='red'),
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Activity</b>: ' + [f'{x:,.0f}' for x in covid_data_21['11 AM']] + '<br>'
                + '<b>Hour</b>: ' + '11 AM' + '<br>'


            ),
                go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['12 PM'],
                mode='lines',
                name='12 PM',
                line=dict(width=3, color='green'),
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Activity</b>: ' + [f'{x:,.0f}' for x in covid_data_21['12 PM']] + '<br>'
                + '<b>Hour</b>: ' + '12 AM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['1 PM'],
                mode='lines',
                name='1 PM',
                line=dict(width=3, color='#000000'),
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Activity</b>: ' + [f'{x:,.0f}' for x in covid_data_21['1 PM']] + '<br>'
                + '<b>Hour</b>: ' + '1 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['2 PM'],
                mode='lines',
                name='2 PM',
                line=dict(width=3, color='#00FF00'),
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Activity</b>: ' + [f'{x:,.0f}' for x in covid_data_21['2 PM']] + '<br>'
                + '<b>Hour</b>: ' + '2 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['3 PM'],
                mode='lines',
                name='3 PM',
                line=dict(width=3, color='#00FFFF'), #cyan
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Activity</b>: ' + [f'{x:,.0f}' for x in covid_data_21['3 PM']] + '<br>'
                + '<b>Hour</b>: ' + '3 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['4 PM'],
                mode='lines',
                name='4 PM',
                line=dict(width=3, color='#008080'), #teal
                hoverinfo='text',
                #visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Activity</b>: ' + [f'{x:,.0f}' for x in covid_data_21['4 PM']] + '<br>'
                + '<b>Hour</b>: ' + '4 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['5 PM'],
                mode='lines',
                name='5 PM',
                line=dict(width=3, color='#000080'), #navy
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Activity</b>: ' + [f'{x:,.0f}' for x in covid_data_21['5 PM']] + '<br>'
                + '<b>Hour</b>: ' + '5 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['6 PM'],
                mode='lines',
                name='6 PM',
                line=dict(width=3, color='#A52A2A'),#brown
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Activity</b>: ' + [f'{x:,.0f}' for x in covid_data_21['6 PM']] + '<br>'
                + '<b>Hour</b>: ' + '6 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['7 PM'],
                mode='lines',
                name='7 PM',
                line=dict(width=3, color='#FF7F50'),#coral
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Activity</b>: ' + [f'{x:,.0f}' for x in covid_data_21['7 PM']] + '<br>'
                + '<b>Hour</b>: ' + '7 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['8 PM'],
                mode='lines',
                name='8 PM',
                line=dict(width=3, color='#FFD700'),#gold
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Activity</b>: ' + [f'{x:,.0f}' for x in covid_data_21['8 PM']] + '<br>'
                + '<b>Hour</b>: ' + '8 PM' + '<br>'


            )
            
            ],

        'layout': go.Layout(
            title={'text': 'Year to date Daily Patron Activity: ' + (w_countries),
                   'y': 0.93,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            titlefont={'color': 'white',
                       'size': 20},
            font=dict(family='sans-serif',
                      color='white',
                      size=12),
            hovermode='closest',
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            legend={'orientation': 'h',
                    'bgcolor': '#1f2c56',
                    'xanchor': 'center', 'x': 0.5, 'y': -0.7},
            margin=dict(r=0),
            xaxis=dict(title='<b>Date</b>',
                       color = 'white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Aerial',
                           color='white',
                           size=12
                       )),
            yaxis=dict(title='<b>Daily Patron Activity</b>',
                       color='white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Aerial',
                           color='white',
                           size=12
                       )
                       )


        )
    }
    ##
@app.callback(Output('multiline_chart1', 'figure'),
              [Input('w_countries1','value')],
              [Input('select_years','value')])
def update_graph(w_countries1,select_years):
    circulationjcb_3 = circulationjcb.groupby(['Trans Stat Station Library','Trans Stat Date', 'Trans Stat Itype', 'year'])['Trans Stat Id'].count().reset_index()
    both = circulationjcb_3[(circulationjcb_3['Trans Stat Station Library'] == w_countries1) & (circulationjcb_3['year'] == select_years)][['Trans Stat Itype','Trans Stat Station Library', 'Trans Stat Date', 'Trans Stat Id']]#.reset_index()
    chromebook = both[both['Trans Stat Itype'] == 'EQ-ECFCB']
    hotspot = both[both['Trans Stat Itype'] == 'EQ-ECFHOT']
    
    

    return {
        'data': [go.Scatter(
            x=chromebook['Trans Stat Date'],
            y=chromebook['Trans Stat Id'],
            mode='lines',
            name='Chromebooks',
            marker=dict(color='orange'),
            hoverinfo='text',
            hovertext=
            '<b>Date</b>: ' + chromebook['Trans Stat Date'].astype(str) + '<br>' +
            '<b>Daily Chromebook Numbers</b>: ' + [f'{x:,.0f}' for x in chromebook['Trans Stat Id']] + '<br>' 
            #+ '<b>Hour</b>: ' + '9 AM' + '<br>'


        ),
        go.Scatter(
            x=hotspot['Trans Stat Date'],
            y=hotspot['Trans Stat Id'],
            mode='lines',
            name='ECF-Hotspots',
            marker=dict(color='blue'),
            hoverinfo='text',
            hovertext=
            '<b>Date</b>: ' + hotspot['Trans Stat Date'].astype(str) + '<br>' +
            '<b>Daily Hotspots Numbers</b>: ' + [f'{x:,.0f}' for x in hotspot['Trans Stat Id']] + '<br>'


        )
        ],

        'layout': go.Layout(
            # title={'text': 'Year to date Daily Patron Activity: ' + (w_countries),
            title={'text': 'Year to date Daily ECF-Chromebooks and ECF-Hotspots checkouts: ' + (w_countries1),
                   'y': 0.93,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            titlefont={'color': 'white',
                       'size': 20},
            font=dict(family='sans-serif',
                      color='white',
                      size=12),
            hovermode='closest',
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            legend={'orientation': 'h',
                    'bgcolor': '#1f2c56',
                    'xanchor': 'center', 'x': 0.5, 'y': -0.7},
            margin=dict(r=0),
            xaxis=dict(title='<b>Date</b>',
                       color = 'white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Aerial',
                           color='white',
                           size=12
                       )),
            yaxis=dict(title='<b>Daily Chromebook</b>',
                       color='white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Aerial',
                           color='white',
                           size=12
                       )
                       )


        )
    }
    
