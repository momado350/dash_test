import dash
from dash import html
import dash_html_components as html
from dash import dcc
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import pandas as pd
# import dash_auth
# from users import USERNAME_PASSWORD_PAIRS
from app import app

it = pd.read_csv('items trans.csv')
lat_long = pd.read_csv('Customer_lat_long.csv')
it = it.drop_duplicates(subset='Trans Hist Id')
lst = ['KC-PUBLIC', 'KC-EDUC','KC-STAFF','MISSING','SCH-ELEM','SCH-HS','KC-CLASS','KC-MONTH','KC-SUSPND']

it = it[it['User Profile'].isin(lst)]
it['Trans Hist Datetime'] = pd.to_datetime(it['Trans Hist Datetime'])
it['hour'] = it['Trans Hist Datetime'].dt.hour
lat_long = lat_long[lat_long['Customers Latitude'].notnull()]
# merge items and users lat long
items = it.merge(lat_long, left_on='User Barcode', right_on='Customers Card Number', how='left')
items = items.drop_duplicates(subset='Trans Hist Id')
items['Trans Hist Date'] = pd.to_datetime(items['Trans Hist Date'])

points = items.groupby(['Station Library Checkout','Customers Cardholder ID', 'Customers Latitude', 'Customers Longitude'])['Trans Hist Id'].count().reset_index()
points1 = points[['Station Library Checkout','Customers Cardholder ID', 'Customers Latitude', 'Customers Longitude']]
list_locations = points1.set_index('Station Library Checkout')[['Customers Latitude', 'Customers Longitude']].T.to_dict('dict')
items_data = items.groupby(['Trans Hist Date'])[['Trans Hist Id']].count().reset_index()
items_dataw = items.groupby([pd.Grouper(key='Trans Hist Date', freq='W-SAT',label='left',closed='left')])[['Trans Hist Id']].count().reset_index()
items_datam = items.groupby([pd.Grouper(key='Trans Hist Date', freq='M')])[['Trans Hist Id']].count().reset_index()

holds = pd.read_csv('Filled Holds with picked up library and user parcode.csv')
layout = html.Div([
    
    html.Div([
        html.Div([
            
        ], className='one-third column'),

        html.Div([
            html.Div([
                html.H3('Items Transaction Dashboard', style={'margin-bottom': '0px', 'color': 'white'}),
                html.H5('Track Transactions by Library Branch', style={'margin-bottom': '0px', 'color': 'white'})
            ])

        ], className='one-half column', id = 'title'),

        html.Div([
            html.H6('Last Updated: ' + str(items['Trans Hist Date'].iloc[-1].strftime('%B %d, %Y')) + ' 00:01 (UTC)',
                    style={'color': 'orange'})

        ], className='one-third column', id = 'title1'),

        html.Div([
            html.P('Select Year', className='fix_label', style= {'color': 'white'}),
            dcc.Slider(id = 'select_years',
                       included=False,
                       updatemode='drag',
                       tooltip={'always_visible': True},
                       min = 2022,
                       max = 2023,
                       step = 1,
                       value=2023,
                       marks={str(yr): str(yr) for yr in range(2022, 2023)},
                       className='dcc_compon'),

        ], className='one-half column', id = 'title2'),
        ], id = 'header', className= 'row flex-display', style={'margin-bottom': '25px'}),

        html.Div([
        html.Div([
            html.H6(children='Year-to-Date Transactions',
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{items['Trans Hist Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{items['Trans Hist Id'].count():,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('Year before (Placeholder): ' + f"{0:,.0f}"
                   + ' (' + str(round(((0-items['Trans Hist Id'].count()) /
                                   items['Trans Hist Id'].count()) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})
            
        ], className='card_container three columns'),

html.Div([
            html.H6(children="Last Month Transactions",
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{items['Trans Hist Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{items_datam ['Trans Hist Id'].iloc[-2]:,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('Month Before: ' + f"{items_datam ['Trans Hist Id'].iloc[-3]:,.0f}"
                   + ' (' + str(round(((items_datam ['Trans Hist Id'].iloc[-2]-items_datam ['Trans Hist Id'].iloc[-3]) /
                                   items_datam ['Trans Hist Id'].iloc[-3]) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})

        ], className='card_container three columns'),

html.Div([
            html.H6(children="Month-to-Date Transactions",
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{items['Trans Hist Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{items_datam ['Trans Hist Id'].iloc[-1]:,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('How far from Last Month: ' + f"{items_datam ['Trans Hist Id'].iloc[-1]-items_datam ['Trans Hist Id'].iloc[-2]:,.0f}"
                   + ' (' + str(round(((items_datam ['Trans Hist Id'].iloc[-1] - items_datam ['Trans Hist Id'].iloc[-2]) / items_datam ['Trans Hist Id'].iloc[-2]) * 100,2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})

        ], className='card_container three columns'),

html.Div([
            html.H6(children="Transactions Last Week",
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{items['Trans Hist Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{items_dataw['Trans Hist Id'].iloc[-1]:,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('Week Before: ' + f"{items_dataw['Trans Hist Id'].iloc[-2]:,.0f}"
                   + ' (' + str(round(((items_dataw['Trans Hist Id'].iloc[-1]-items_dataw['Trans Hist Id'].iloc[-2]) /
                                   items_dataw['Trans Hist Id'].iloc[-2]) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})

        ], className='card_container three columns'),

    ], className='row flex display'),

        html.Div([
        html.Div([


            html.P('Select Branch', className = 'fix_label', style = {'color': 'White', 'margin-top': '2px'}),
            dcc.Dropdown(id = 'select_state2',
                         multi = False,
                         clearable = True,
                         disabled = False,
                         style = {'display': True},
                         value = 'KC-BLUFORD',
                         placeholder = 'Select state',
                         options = [{'label': c, 'value': c}
                                    for c in (items['Station Library Checkout'].unique())], className = 'dcc_compon'),
            # html.H1('Points are Users who Checkout Items and Colors represent Number of Items Checked out by Users', className = 'fix_label', style = {'color': 'White', 'margin-top': '2px'}),


            ], className = "create_container2 four columns", style = {'margin-bottom': '20px', "margin-top": "20px"}),

    ], className = "row flex-display"),

            html.Div([
                html.Div([

                    dcc.Graph(id = 'map_6',
                              config = {'displayModeBar': 'hover'}),

            html.H1('Points are Users who Checkout Items and Colors represent Number of Items Checked out by Users', className = 'fix_label', style = {'color': 'White', 'margin-top': '2px'}),
                ], className = "create_container2 seven columns", style = {'height': '610px'}),
# end map chart layout ----------------------------------------------
            html.Div([
                    dcc.Graph(id = 'bar_items', config={'displayModeBar': 'hover'}
                      )
        ], className='create_container five columns'),

            ], className = "row flex-display"),
# end Bar chart layout ----------------------------------------------            
            
            html.Div([
                    html.Div([
                        html.P('Branch Titem: ' + ' ' + str(items['Trans Hist Date'].iloc[-1].strftime('%B %d, %Y')),
                            className='fix_label', style={'text-align': 'center', 'color': 'white'}),
                        dcc.Graph(id = 'confirmedTransactions', config={'displayModeBar': False}, className='dcc_compon',
                                style={'margin-top': '20px'}),
            dcc.Graph(id = 'monthTransactions', config={'displayModeBar': False}, className='dcc_compon',
                                style={'margin-top': '20px'}),
            dcc.Graph(id = 'weektransactions', config={'displayModeBar': False}, className='dcc_compon',
                                style={'margin-top': '20px'}),
            # dcc.Graph(id = 'active', config={'displayModeBar': False}, className='dcc_compon',
            #                       style={'margin-top': '20px'})

                    ], className='create_container two columns'),

                    html.Div([
            dcc.Graph(id = 'line_cchart_trans', config={'displayModeBar': 'hover'}
                                )
                    ], className='create_container four columns'),

            html.Div([
            dcc.Graph(id = 'multi_line_chart', config={'displayModeBar': 'hover'}
                                )
                    ], className='create_container six columns'),

                ], className='row flex-display'),
                        

## remove the the second select branch and use the only one on to

        ], id = 'mainContainer', style={'display': 'flex', 'flex-direction': 'column'})
#multiline chart
@app.callback(Output('multi_line_chart', 'figure'),
              [Input('select_state2', 'value')]
              )
def update_graph(select_state2):
    holds_trend = holds.groupby(['Hold Inactive Reason', 'Hold Inactive Date', 'Hold Pickup Library Code'])['Hold Id'].count().reset_index()
    hold_df = holds_trend[holds_trend['Hold Pickup Library Code']==select_state2][['Hold Inactive Date', 'Hold Inactive Reason', 'Hold Id']].reset_index()
    filled=hold_df[hold_df['Hold Inactive Reason']=='FILLED'].reset_index()
    canceled = hold_df[hold_df['Hold Inactive Reason']=='CANCELLED'].reset_index()
    expired=hold_df[hold_df['Hold Inactive Reason']=='EXPIRED'].reset_index()
    exp_onshelf=hold_df[hold_df['Hold Inactive Reason']=='EXP_ONSHLF'].reset_index()
   

    return {
        'data':[go.Scatter(
                    x=filled['Hold Inactive Date'],
                    y=filled['Hold Id'],
                    mode = 'markers+lines',
                    name='Filled Holds',
                    line = dict(shape = "spline", smoothing = 1.3, width = 3, color = 'green'),
                    marker = dict(size = 1, symbol = 'circle', color = 'white',
                          line = dict(color = 'orange', width = 2)
                          ),

                  hoverinfo='text',
                  #visible='legendonly',
                  hovertext=
                  '<b>Date</b>: ' + filled['Hold Inactive Date'].astype(str) + '<br>' +
                  '<b>Type</b>: ' + filled['Hold Inactive Reason'].astype(str) + '<br>' +
                  '<b>Count</b>: ' + [f'{x:,.0f}' for x in filled['Hold Id']] + '<br>'



              ),

              go.Scatter(
                x = canceled['Hold Inactive Date'],
                y = canceled['Hold Id'],
                mode = 'markers+lines',
                #mode = 'lines',
                name = 'Cancelled Holds',
                line = dict(shape = "spline", smoothing = 1.3, width = 3, color = 'grey'),
                marker = dict(size = 1, symbol = 'circle', color = 'white',
                              line = dict(color = '#FF00FF', width = 2)
                              ),

                hoverinfo = 'text',
                visible='legendonly',
                hovertext =
                '<b>Date</b>: ' + canceled['Hold Inactive Date'].astype(str) + '<br>' +
                '<b>Type</b>: ' + canceled['Hold Inactive Reason'].astype(str) + '<br>' +
                '<b>Count</b>: ' + [f'{x:,.0f}' for x in canceled['Hold Id']] + '<br>'

            ),

            go.Scatter(
                x = expired['Hold Inactive Date'],
                y = expired['Hold Id'],
                mode = 'markers+lines',
                #mode = 'lines',
                name = 'Expired Holds',
                line = dict(shape = "spline", smoothing = 1.3, width = 3, color = '#FF00FF'),
                marker = dict(size = 1, symbol = 'circle', color = 'white',
                              line = dict(color = '#FF00FF', width = 2)
                              ),

                hoverinfo = 'text',
                visible='legendonly',
                hovertext =
                '<b>Date</b>: ' + expired['Hold Inactive Date'].astype(str) + '<br>' +
                '<b>Type</b>: ' + expired['Hold Inactive Reason'].astype(str) + '<br>' +
                '<b>Count</b>: ' + [f'{x:,.0f}' for x in expired['Hold Id']] + '<br>'

            ),

            go.Scatter(
                x = exp_onshelf['Hold Inactive Date'],
                y = exp_onshelf['Hold Id'],
                mode = 'markers+lines',
                #mode = 'lines',
                name = 'EXP_ONSHLF Holds',
                line = dict(shape = "spline", smoothing = 1.3, width = 3, color = '#464146'),
                marker = dict(size = 1, symbol = 'circle', color = 'white',
                              line = dict(color = '#FF00FF', width = 2)
                              ),

                hoverinfo = 'text',
                visible='legendonly',
                hovertext =
                '<b>Date</b>: ' + exp_onshelf['Hold Inactive Date'].astype(str) + '<br>' +
                '<b>Type</b>: ' + exp_onshelf['Hold Inactive Reason'].astype(str) + '<br>' +
                '<b>Count</b>: ' + [f'{x:,.0f}' for x in exp_onshelf['Hold Id']] + '<br>'

            )],


        'layout': go.Layout(
            # barmode = 'group',
             plot_bgcolor='#1f2c56',
             paper_bgcolor='#1f2c56',
             title={
                'text': 'Holds Trend By Hold inactive Reason at ' + (select_state2),

                'y': 0.98,
                'x': 0.5,
                'xanchor': 'center',
                'yanchor': 'top'},
             titlefont={
                        'color': 'white',
                        'size': 20},

             hovermode='x',

             xaxis=dict(title='<b>Date</b>',
                        # tick0=0,
                        # dtick=1,
                        color='white',
                        showline=True,
                        showgrid=True,
                        linecolor='white',
                        linewidth=1,


                ),

             yaxis=dict(title='<b>Count</b>',
                        color='white',
                        showline=False,
                        showgrid=True,
                        linecolor='white',

                ),

            legend = {
                'orientation': 'h',
                'bgcolor': '#1f2c56',
                'x': 0.5,
                'y': 1.25,
                'xanchor': 'center',
                'yanchor': 'top'},
            font = dict(
                family = "sans-serif",
                size = 12,
                color = 'white')


                 )

    }
## Branch metrics
@app.callback(Output('confirmedTransactions', 'figure'),
              [Input('select_state2','value')],
              [Input('select_years','value')])
def update_confirmed(select_state2, select_years):
    Transactions_data_1 = items.groupby(['Station Library Checkout', 'Trans Hist Date'])['Trans Hist Id'].count().reset_index()
    # Transactions_data_1 = df.groupby(['Station Library Checkout'])[['Trans Hist Id']].sum().reset_index()
    value_confirmed = Transactions_data_1[Transactions_data_1['Station Library Checkout'] == select_state2]['Trans Hist Id'].sum()
    delta_confirmed = 0

    return {
        'data': [go.Indicator(
               mode='number+delta',
               value=value_confirmed,
               delta = {'reference': delta_confirmed,
                        'position': 'right',
                        'valueformat': ',i',
                        'relative': False,
                        'font': {'size': 15}},
               number={'valueformat': ',',
                       'font': {'size': 20}},
               domain={'y': [0, 1], 'x': [0, 1]}
        )],

        'layout': go.Layout(
            title={'text': 'Year-to-Date Transactions',
                   'y': 1,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            font=dict(color='orange'),
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            height = 50,

        )
    }

@app.callback(Output('monthTransactions', 'figure'),
              [Input('select_state2','value')],
              [Input('select_years','value')])
def update_confirmed(select_state2, select_years):
    mer_df_2 = items.groupby(['Station Library Checkout', 'Trans Hist Date'])['Trans Hist Id'].count().reset_index()
    mer_df_2 = mer_df_2.groupby(['Station Library Checkout', pd.Grouper(key='Trans Hist Date', freq='M',)])[['Trans Hist Id']].sum().reset_index()
    #mer_df_2 = items.groupby(['Station Library Checkout', 'Trans Hist Date'])['Trans Hist Id'].count().reset_index()
    value_death = mer_df_2[mer_df_2['Station Library Checkout'] == select_state2]['Trans Hist Id'].iloc[-2]
    delta_death = mer_df_2[mer_df_2['Station Library Checkout'] == select_state2]['Trans Hist Id'].iloc[-3]

    return {
        'data': [go.Indicator(
               mode='number+delta',
               value=value_death,
               delta = {'reference': delta_death,
                        'position': 'right',
                        'valueformat': ',i',
                        'relative': False,
                        'font': {'size': 15}},
               number={'valueformat': ',',
                       'font': {'size': 20}},
               domain={'y': [0, 1], 'x': [0, 1]}
        )],

        'layout': go.Layout(
            title={'text': 'Transactions Last Month',
                   'y': 1,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            font=dict(color='orange'),
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            height = 50,

        )
    }





@app.callback(Output('weektransactions', 'figure'),
              [Input('select_state2','value')],
              [Input('select_years','value')])
def update_confirmed(select_state2, select_years):
    covid_data_2 = items.groupby(['Station Library Checkout', 'Trans Hist Date'])['Trans Hist Id'].count().reset_index()
    covid_data_2 = covid_data_2.groupby(['Station Library Checkout', pd.Grouper(key='Trans Hist Date', freq='W-SAT',label='left',closed='left')])[['Trans Hist Id']].sum().reset_index()
    value_recovered = covid_data_2[covid_data_2['Station Library Checkout'] == select_state2]['Trans Hist Id'].iloc[-2]
    delta_recovered = covid_data_2[covid_data_2['Station Library Checkout'] == select_state2]['Trans Hist Id'].iloc[-3]

    return {
        'data': [go.Indicator(
               mode='number+delta',
               value=value_recovered,
               delta = {'reference': delta_recovered,
                        'position': 'right',
                        'valueformat': ',i',
                        'relative': False,
                        'font': {'size': 15}},
               number={'valueformat': ',',
                       'font': {'size': 20}},
               domain={'y': [0, 1], 'x': [0, 1]}
        )],

        'layout': go.Layout(
            title={'text': 'Transactions Last Week',
                   'y': 1,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            font=dict(color='orange'),
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            height = 50,

        )
    }

## Line chart
@app.callback(Output('line_cchart_trans', 'figure'),
              [Input('select_state2','value')],
              [Input('select_years','value')])
def update_graph(select_state2, select_years):
    covid_data_2 = items.groupby(['Station Library Checkout', 'Trans Hist Date'])['Trans Hist Id'].count().reset_index()
    covid_data_21 = covid_data_2[covid_data_2['Station Library Checkout'] == select_state2][['Station Library Checkout', 'Trans Hist Date', 'Trans Hist Id']].reset_index()
    covid_data_21['daily confirmed'] = covid_data_21['Trans Hist Id']#.shift(0)
    covid_data_21['Rolling Ave.'] = covid_data_21['Trans Hist Id'].rolling(window=7).mean()


    return {
        'data': [go.Line(
            x=covid_data_21['Trans Hist Date'], #.tail(30)
            y=covid_data_21['daily confirmed'], #.tail(30)
            name='Daily Item Transactions',
            marker=dict(color='orange'),
            hoverinfo='text',
            hovertext=
            '<b>Date</b>: ' + covid_data_21['Trans Hist Date'].astype(str) + '<br>' +
            '<b>Daily Transactions Numbers</b>: ' + [f'{x:,.0f}' for x in covid_data_21['daily confirmed']] + '<br>' +
            '<b>Branch</b>: ' + covid_data_21['Station Library Checkout'].astype(str) + '<br>'


        ),
            go.Scatter(
                x=covid_data_21['Trans Hist Date'],
                y=covid_data_21['Rolling Ave.'],
                mode='lines',
                name='Rolling Average of the last 7 days - daily transactions',
                line=dict(width=3, color='#FF00FF'),
                hoverinfo='text',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['Trans Hist Date'].astype(str) + '<br>' +
                '<b>Daily Transactions</b>: ' + [f'{x:,.0f}' for x in covid_data_21['Rolling Ave.']] + '<br>'


            )],

        'layout': go.Layout(
            title={'text': 'Daily Item Transactions at ' + (select_state2),
                   'y': 0.93,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            titlefont={'color': 'white',
                       'size': 20},
            font=dict(family='sans-serif',
                      color='white',
                      size=12),
            hovermode='closest',
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            legend={'orientation': 'h',
                    'bgcolor': '#1f2c56',
                    'xanchor': 'center', 'x': 0.5, 'y': -0.7},
            margin=dict(r=0),
            xaxis=dict(title='<b>Date</b>',
                       color = 'white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Aerial',
                           color='white',
                           size=12
                       )),
            yaxis=dict(title='<b>Daily Items Transactions</b>',
                       color='white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Aerial',
                           color='white',
                           size=12
                       )
                       )


        )
    }


#bar Chart
@app.callback(Output('bar_items', 'figure'),
              [Input('select_state2','value')],
              [Input('select_years','value')])
def update_graph(select_state2, select_years):

    covid_data_2 = items.groupby(['Station Library Checkout', 'Item Type'])['Trans Hist Id'].count().reset_index()
    covid_data_21 = covid_data_2[covid_data_2['Station Library Checkout'] == select_state2][['Station Library Checkout','Item Type', 'Trans Hist Id']].reset_index()
    covid_data_21['daily confirmed'] = covid_data_21['Trans Hist Id']
    #covid_data_21['Rolling Ave.'] = covid_data_21['Trans Hist Id'].rolling(window=7).mean()


    return {
        'data': [go.Bar(
            x=covid_data_21['Item Type'],
            y=covid_data_21['daily confirmed'],
            name='Daily Patron Titem',
            marker=dict(color='orange'),
            hoverinfo='text',
            hovertext=
            '<b>Date</b>: ' + covid_data_21['Item Type'] + '<br>' +
            '<b>Daily Titem Numbers</b>: ' + [f'{x:,.0f}' for x in covid_data_21['daily confirmed']] + '<br>' +
            '<b>Branch</b>: ' + covid_data_21['Station Library Checkout'] + '<br>'
        )],

        'layout': go.Layout(
            title={'text': 'Year-to-Date Comparison of Item-types checkedout at ' + (select_state2),
                   'y': 0.93,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            titlefont={'color': 'white',
                       'size': 20},
            font=dict(family='sans-serif',
                      color='white',
                      size=12),
            hovermode='closest',
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            legend={'orientation': 'h',
                    'bgcolor': '#1f2c56',
                    'xanchor': 'center', 'x': 0.5, 'y': -0.7},
            margin=dict(r=0),
            xaxis=dict(title='<b></b>',
                       color='white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Arial',
                           color='white',
                           size=13,
                       ),
                       title_standoff=1  # Set the title_standoff value as needed
                       ),
            yaxis=dict(title='<b>Transactions</b>',
                       color='white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Arial',
                           color='white',
                           size=12
                       )
                       )
        )
    }
# Map Chart
@app.callback(Output('map_6', 'figure'),
              [Input('select_state2', 'value')])
def update_graph(select_state2):
    #cities1 = cities.groupby(['State', 'City', 'lat', 'lon'])['Population'].sum().reset_index()
    cities1 = items.groupby(['Station Library Checkout','Customers Cardholder ID', 'Customers Latitude', 'Customers Longitude'])['Trans Hist Id'].count().reset_index()
    # cities2 = cities1[cities1['State'] == select_state2]
    cities2 = cities1[cities1['Station Library Checkout'] == select_state2]

    if select_state2:
        zoom = 10
        zoom_lat = list_locations[select_state2]['Customers Latitude']
        zoom_lon = list_locations[select_state2]['Customers Longitude']

    return {
        'data': [go.Scattermapbox(
            lon = cities2['Customers Longitude'],
            lat = cities2['Customers Latitude'],
            mode = 'markers',
            marker=go.scattermapbox.Marker(
                size = 12,
                color = cities2['Trans Hist Id'],
                colorscale = 'RdBu',
                showscale = True,
                cmin = 1,  # Set the minimum value for the color scale
                cmax = 50,  # Set the maximum value for the color scale
                sizemode = 'area'),

            hoverinfo = 'text',
            hovertext =
            '<b>Branch</b>: ' + cities2['Station Library Checkout'].astype(str) + '<br>' +
            '<b>CardID</b>: ' + cities2['Customers Cardholder ID'].astype(str) + '<br>' +
            '<b>Lat</b>: ' + [f'{x:.4f}' for x in cities2['Customers Latitude']] + '<br>' +
            '<b>Long</b>: ' + [f'{x:.4f}' for x in cities2['Customers Longitude']] + '<br>' +
            '<b>Number of Items</b>: ' + [f'{x:,.0f}' for x in cities2['Trans Hist Id']] + '<br>'

        )],

        'layout': go.Layout(
            height = 580,
             margin={"r": 0, "t": 0, "l": 0, "b": 0},
             hovermode='closest',
             mapbox=dict(
                accesstoken='pk.eyJ1IjoicXM2MjcyNTI3IiwiYSI6ImNraGRuYTF1azAxZmIycWs0cDB1NmY1ZjYifQ.I1VJ3KjeM-S613FLv3mtkw',  # Create free account on Mapbox site and paste here access token
                center=dict(lat=zoom_lat, lon=zoom_lon),
                style='open-street-map',
                # style='dark',
                zoom=zoom,
                bearing = 0
             ),
             autosize=True,

        )

    }