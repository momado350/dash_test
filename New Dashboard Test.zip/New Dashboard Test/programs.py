import dash
from dash import html
import dash_html_components as html
from dash import dcc
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import pandas as pd
import plotly.express as px
# import dash_auth
# from users import USERNAME_PASSWORD_PAIRS
from app import app

df1 = pd.read_excel('Programming Responses 2023_2024.xlsx')
df0 = pd.read_excel('Programming Responses 2022_2023.xlsx')
df = pd.concat([df0, df1], ignore_index=True)
df['Date'] = pd.to_datetime(df['Program Date'])
df['year'] = df['Program Date'].dt.year
df = df[df['year'] >= 2023]
df = df[(df['Live In-Person Attendance']!='No Meeting') & (df['Live In-Person Attendance']!='test')]
df['Location'] = df['Location'].fillna(' ')
df['Program Category'] = df['Program Category'].fillna(' ')

df['Live In-Person Attendance'] = df['Live In-Person Attendance'].fillna(0)
df = df.loc[~df['Live In-Person Attendance'].astype(str).str.isdigit()]
def map_branch_name(branch):
    branch_lower = branch.lower()
    if 'westport' in branch_lower:
        return 'Westport'
    elif 'central' in branch_lower:
        return 'Central'
    elif 'plaza' in branch_lower:
        return 'Plaza'
    elif 'waldo' in branch_lower:
        return 'waldo'
    elif 'ruiz' in branch_lower:
        return 'Ruiz'
    elif 'north-east' in branch_lower or 'northeast' in branch_lower:
        return 'North-East'
    elif 'south-east' in branch_lower or 'southeast' in branch_lower:
        return 'South-East'
    elif 'trails' in branch_lower:
        return 'Trails West'
    elif 'sugar creek' in branch_lower:
        return 'Sugar Creek'
    elif 'bluford' in branch_lower:
        return 'Bluford'
    else:
        return 'Other'
# Apply the mapping function to the 'branch' column and create the new 'NewValue' column
df['Branch'] = df['Location'].apply(map_branch_name)
dfb = df[df['Branch'] != 'Other']


items_data = df.groupby(['Date'])[['Program Date']].count().reset_index()
items_dataw = df.groupby([pd.Grouper(key='Date', freq='W-SAT',label='left',closed='left')])[['Program Date']].count().reset_index()
items_datam = df.groupby([pd.Grouper(key='Date', freq='M')])[['Program Date']].count().reset_index()

holds = pd.read_csv('Filled Holds with picked up library and user parcode.csv')
layout = html.Div([
    
    html.Div([
        html.Div([
            
        ], className='one-third column'),

        html.Div([
            html.Div([
                html.H3('Programs Dashboard', style={'margin-bottom': '0px', 'color': 'white'}),
                html.H5('Track Programs by Library Branch', style={'margin-bottom': '0px', 'color': 'white'})
            ])

        ], className='one-half column', id = 'title'),

        html.Div([
            html.H6('Last Updated: ' + str(df['Date'].iloc[-1].strftime('%B %d, %Y')) + ' 00:01 (UTC)',
                    style={'color': 'orange'})

        ], className='one-third column', id = 'title1'),

        html.Div([
            html.P('Select Year', className='fix_label', style= {'color': 'white'}),
            dcc.Slider(id = 'select_years',
                       included=False,
                       updatemode='drag',
                       tooltip={'always_visible': True},
                       min = 2022,
                       max = 2023,
                       step = 1,
                       value=2023,
                       marks={str(yr): str(yr) for yr in range(2022, 2023)},
                       className='dcc_compon'),

        ], className='one-half column', id = 'title2'),
        ], id = 'header', className= 'row flex-display', style={'margin-bottom': '25px'}),

        html.Div([
        html.Div([
            html.H6(children='Year-to-Date Programs',
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{df['Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{df['Program Date'].count():,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('Year before (Placeholder): ' + f"{0:,.0f}"
                   + ' (' + str(round(((df['Program Date'].count()) /
                                   df['Program Date'].count()) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})
            
        ], className='card_container three columns'),

html.Div([
            html.H6(children="Last Month Programs",
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{df['Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{items_datam ['Program Date'].iloc[-2]:,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('Month Before: ' + f"{items_datam ['Program Date'].iloc[-3]:,.0f}"
                   + ' (' + str(round(((items_datam ['Program Date'].iloc[-2]-items_datam ['Program Date'].iloc[-3]) /
                                   items_datam ['Program Date'].iloc[-3]) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})

        ], className='card_container three columns'),

html.Div([
            html.H6(children="Month-to-Date Programs",
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{df['Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{items_datam ['Program Date'].iloc[-1]:,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('How far from Last Month: ' + f"{items_datam ['Program Date'].iloc[-1]-items_datam ['Program Date'].iloc[-2]:,.0f}"
                   + ' (' + str(round(((items_datam ['Program Date'].iloc[-1] - items_datam ['Program Date'].iloc[-2]) / items_datam ['Program Date'].iloc[-2]) * 100,2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})

        ], className='card_container three columns'),

html.Div([
            html.H6(children="Programs Last Week",
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{df['Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{items_dataw['Program Date'].iloc[-1]:,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('Week Before: ' + f"{items_dataw['Program Date'].iloc[-2]:,.0f}"
                   + ' (' + str(round(((items_dataw['Program Date'].iloc[-1]-items_dataw['Program Date'].iloc[-2]) /
                                   items_dataw['Program Date'].iloc[-2]) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})

        ], className='card_container three columns'),

    ], className='row flex display'),

    

            html.Div([
                 html.Div([
                    dcc.Graph(id = 'line_total', config={'displayModeBar': 'hover'}
                      )
        ], className='create_container four columns'),
        #Pie chart
        html.Div([
                    dcc.Graph(id = 'pie_pro', config={'displayModeBar': 'hover'}
                      )
        ], className='create_container four columns'),
# end map chart layout ----------------------------------------------
            html.Div([
                    dcc.Graph(id = 'bar_pro', config={'displayModeBar': 'hover'}
                      )
        ], className='create_container four columns'),

            ], className = "row flex-display"),
# end Bar chart layout ---------------------------------------------- week_pro           
            
            html.Div([
                    html.Div([
                         html.P('Select Branch', className = 'fix_label', style = {'color': 'White', 'margin-top': '2px'}),
            dcc.Dropdown(id = 'select_state2',
                         multi = False,
                         clearable = True,
                         disabled = False,
                         style = {'display': True},
                         value = 'Central',
                         placeholder = 'Select state',
                         options = [{'label': c, 'value': c}
                                    for c in (df[df['Branch'] != 'Other']['Branch'].unique())], className = 'dcc_compon'),
                        dcc.Graph(id = 'total_pro', config={'displayModeBar': False}, className='dcc_compon',
                                style={'margin-top': '20px'}),
            dcc.Graph(id = 'month_pro', config={'displayModeBar': False}, className='dcc_compon',
                                style={'margin-top': '20px'}),
            dcc.Graph(id = 'week_pro', config={'displayModeBar': False}, className='dcc_compon',
                                style={'margin-top': '20px'}),
            # dcc.Graph(id = 'active', config={'displayModeBar': False}, className='dcc_compon',
            #                       style={'margin-top': '20px'})

                    ], className='create_container two columns'),

                    html.Div([
            dcc.Graph(id = 'line_pro', config={'displayModeBar': 'hover'}
                                )
                    ], className='create_container four columns'),

            html.Div([
            dcc.Graph(id = 'multi_pro', config={'displayModeBar': 'hover'}
                                )
                    ], className='create_container six columns'),

                ], className='row flex-display'),
                        

## remove the the second select branch and use the only one on to

        ], id = 'mainContainer', style={'display': 'flex', 'flex-direction': 'column'})
## pie chart
@app.callback(Output('pie_pro', 'figure'),
              [Input('select_state2', 'value')]
              )
def update_graph(select_state2):
    traffic_data_11 = df.groupby(['Audience'])['Program Date'].count().reset_index()
    

    return {
        'data': [go.Pie(
            labels=traffic_data_11['Audience'],
            values=traffic_data_11['Program Date'],
            marker=dict(colors=['viridis']),
            hoverinfo='label+value+percent',
            textinfo='label+value+percent',
            hole=0.7,
            rotation=45,
        )],
        'layout': go.Layout(
            title={'text': 'Year-to-Date Programs Audience: ',
                   'y': 0.93,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            titlefont={'color': 'white',
                       'size': 20},
            font=dict(family='sans-serif',
                      color='white',
                      size=12),
            hovermode='closest',
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            legend={'orientation': 'h',
                    'bgcolor': '#1f2c56',
                    'xanchor': 'center', 'x': 0.5, 'y': -0.7}
        )
    }

#multiline chart
@app.callback(Output('multi_pro', 'figure'),
              [Input('select_state2', 'value')]
              )
def update_graph(select_state2):
    holds_trend = dfb.groupby(['Date', 'Branch'])[['Program Date']].count().reset_index()
    filled = holds_trend[holds_trend['Branch']==select_state2][['Date', 'Program Date']].reset_index()
    #dfb['Live In-Person Attendance'] = dfb['Live In-Person Attendance'].str.extract(r'(\d+)')
    holds_trend2 = dfb.groupby(['Date', 'Branch'])[['Live In-Person Attendance']].sum().reset_index()
    canceled = holds_trend2[holds_trend2['Branch']==select_state2][['Date', 'Live In-Person Attendance']].reset_index()

    

    return {
        'data':[go.Scatter(
                    x=filled['Date'],
                    y=filled['Program Date'],
                    mode = 'markers+lines',
                    name='Programs',
                    line = dict(shape = "spline", smoothing = 1.3, width = 3, color = 'green'),
                    marker = dict(size = 1, symbol = 'circle', color = 'white',
                          line = dict(color = 'orange', width = 2)
                          ),

                  hoverinfo='text',
                  #visible='legendonly',
                  hovertext=
                  '<b>Date</b>: ' + filled['Date'].astype(str) + '<br>' +
                  '<b>Programs</b>: ' + [f'{x:,.0f}' for x in filled['Program Date']] + '<br>'



              ),

              go.Scatter(
                x = canceled['Date'],
                y = canceled['Live In-Person Attendance'],
                mode = 'markers+lines',
                #mode = 'lines',
                name = 'Attendance',
                line = dict(shape = "spline", smoothing = 1.3, width = 3, color = 'grey'),
                marker = dict(size = 1, symbol = 'circle', color = 'white',
                              line = dict(color = '#FF00FF', width = 2)
                              ),

                hoverinfo = 'text',
                visible='legendonly',
                hovertext =
                '<b>Date</b>: ' + canceled['Date'].astype(str) + '<br>' +
                '<b>Programs</b>: ' + [f'{x:,.0f}' for x in canceled['Live In-Person Attendance']] + '<br>'

            )

           ],


        'layout': go.Layout(
            # barmode = 'group',
             plot_bgcolor='#1f2c56',
             paper_bgcolor='#1f2c56',
             title={
                'text': 'Program Trend at ' + (select_state2),

                'y': 0.98,
                'x': 0.5,
                'xanchor': 'center',
                'yanchor': 'top'},
             titlefont={
                        'color': 'white',
                        'size': 20},

             hovermode='x',

             xaxis=dict(title='<b>Date</b>',
                        # tick0=0,
                        # dtick=1,
                        color='white',
                        showline=True,
                        showgrid=True,
                        linecolor='white',
                        linewidth=1,


                ),

             yaxis=dict(title='<b>Count</b>',
                        color='white',
                        showline=False,
                        showgrid=True,
                        linecolor='white',

                ),

            legend = {
                'orientation': 'h',
                'bgcolor': '#1f2c56',
                'x': 0.5,
                'y': 1.25,
                'xanchor': 'center',
                'yanchor': 'top'},
            font = dict(
                family = "sans-serif",
                size = 12,
                color = 'white')


                 )

    }
## Branch metrics
@app.callback(Output('total_pro', 'figure'),
              [Input('select_state2','value')],
              [Input('select_years','value')])
def update_confirmed(select_state2, select_years):
    Transactions_data_1 = dfb.groupby(['Branch','Date'])[['Program Date']].count().reset_index()
    # Transactions_data_1 = df.groupby(['Station Library Checkout'])[['Trans Hist Id']].sum().reset_index()
    value_confirmed = Transactions_data_1[Transactions_data_1['Branch'] == select_state2]['Program Date'].sum()
    delta_confirmed = 0

    return {
        'data': [go.Indicator(
               mode='number+delta',
               value=value_confirmed,
               delta = {'reference': delta_confirmed,
                        'position': 'right',
                        'valueformat': ',i',
                        'relative': False,
                        'font': {'size': 15}},
               number={'valueformat': ',',
                       'font': {'size': 20}},
               domain={'y': [0, 1], 'x': [0, 1]}
        )],

        'layout': go.Layout(
            title={'text': 'Year-to-Date Programs',
                   'y': 1,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            font=dict(color='orange'),
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            height = 50,

        )
    }

@app.callback(Output('month_pro', 'figure'),
              [Input('select_state2','value')],
              [Input('select_years','value')])
def update_confirmed(select_state2, select_years):
    mer_df_2 = dfb.groupby(['Branch','Date'])[['Program Date']].count().reset_index()
    mer_df_2 = mer_df_2.groupby(['Branch', pd.Grouper(key='Date', freq='M',)])[['Program Date']].sum().reset_index()
    #mer_df_2 = items.groupby(['Station Library Checkout', 'Trans Hist Date'])['Trans Hist Id'].count().reset_index()
    value_death = mer_df_2[mer_df_2['Branch'] == select_state2]['Program Date'].iloc[-2]
    delta_death = mer_df_2[mer_df_2['Branch'] == select_state2]['Program Date'].iloc[-3]

    return {
        'data': [go.Indicator(
               mode='number+delta',
               value=value_death,
               delta = {'reference': delta_death,
                        'position': 'right',
                        'valueformat': ',i',
                        'relative': False,
                        'font': {'size': 15}},
               number={'valueformat': ',',
                       'font': {'size': 20}},
               domain={'y': [0, 1], 'x': [0, 1]}
        )],

        'layout': go.Layout(
            title={'text': 'Programs Last Month',
                   'y': 1,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            font=dict(color='orange'),
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            height = 50,

        )
    }





@app.callback(Output('week_pro', 'figure'),
              [Input('select_state2','value')],
              [Input('select_years','value')])
def update_confirmed(select_state2, select_years):
    covid_data_2 = dfb.groupby(['Branch','Date'])[['Program Date']].count().reset_index()
    covid_data_2 = covid_data_2.groupby(['Branch', pd.Grouper(key='Date', freq='W-SAT',label='left',closed='left')])[['Program Date']].sum().reset_index()
    value_recovered = covid_data_2[covid_data_2['Branch'] == select_state2]['Program Date'].iloc[-2]
    delta_recovered = covid_data_2[covid_data_2['Branch'] == select_state2]['Program Date'].iloc[-3]

    return {
        'data': [go.Indicator(
               mode='number+delta',
               value=value_recovered,
               delta = {'reference': delta_recovered,
                        'position': 'right',
                        'valueformat': ',i',
                        'relative': False,
                        'font': {'size': 15}},
               number={'valueformat': ',',
                       'font': {'size': 20}},
               domain={'y': [0, 1], 'x': [0, 1]}
        )],

        'layout': go.Layout(
            title={'text': 'Programs Last Week',
                   'y': 1,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            font=dict(color='orange'),
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            height = 50,

        )
    }

## Line chart
@app.callback(Output('line_pro', 'figure'),
              [Input('select_state2','value')],
              [Input('select_years','value')])
def update_graph(select_state2, select_years):
    traffic_data_1 = dfb.groupby(['Branch','Audience'])['Program Date'].count().reset_index()
    traffic_data_11 = traffic_data_1[traffic_data_1['Branch'] == select_state2]
    

    return {
        'data': [go.Pie(
            labels=traffic_data_11['Audience'],
            values=traffic_data_11['Program Date'],
            marker=dict(colors=['viridis']),
            hoverinfo='label+value+percent',
            textinfo='label+value+percent',
            hole=0.7,
            rotation=45,
        )],
        'layout': go.Layout(
            title={'text': 'Year-to-Date Programs Audience at ' + (select_state2),
                   'y': 0.93,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            titlefont={'color': 'white',
                       'size': 20},
            font=dict(family='sans-serif',
                      color='white',
                      size=12),
            hovermode='closest',
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            legend={'orientation': 'h',
                    'bgcolor': '#1f2c56',
                    'xanchor': 'center', 'x': 0.5, 'y': -0.7}
        )
    }

#bar Chart
@app.callback(Output('bar_pro', 'figure'),
              [Input('select_state2','value')],
              [Input('select_years','value')])
def update_graph(select_state2, select_years):
    df1 = df[df['Branch']!= 'Other']
    covid_data_21 = df1.groupby(df1['Branch'])['Program Date'].count().reset_index()
    

    return {
        'data': [go.Bar(
            x=covid_data_21['Branch'],
            y=covid_data_21['Program Date'],
            name='Number of Programs',
            marker=dict(color=px.colors.sequential.Viridis),#colorscale='Viridis'
            #marker=dict(colorscale='Viridis'),
            hoverinfo='text',
            hovertext=
            '<b>Branch</b>: ' + covid_data_21['Branch'] + '<br>' +
            '<b>Total Programs</b>: ' + [f'{x:,.0f}' for x in covid_data_21['Program Date']] + '<br>'
            
        )],

        'layout': go.Layout(
            title={'text': 'Number of Programs by Library Branch ',
                   'y': 0.93,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            titlefont={'color': 'white',
                       'size': 20},
            font=dict(family='sans-serif',
                      color='white',
                      size=12),
            hovermode='closest',
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            legend={'orientation': 'h',
                    'bgcolor': '#1f2c56',
                    'xanchor': 'center', 'x': 0.5, 'y': -0.7},
            margin=dict(r=0),
            xaxis=dict(title='<b></b>',
                       color='white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Arial',
                           color='white',
                           size=13,
                       ),
                       title_standoff=1  # Set the title_standoff value as needed
                       ),
            yaxis=dict(title='<b>Programs</b>',
                       color='white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Arial',
                           color='white',
                           size=12
                       )
                       )
        )
    }

@app.callback(Output('line_total', 'figure'),
              [Input('select_state2', 'value')]
              )
def update_graph(select_state2):
    filled = df.groupby(['Date'])[['Program Date']].count().reset_index()
    # hold_df = holds_trend[holds_trend['Hold Pickup Library Code']==select_state2][['Hold Inactive Date', 'Hold Inactive Reason', 'Hold Id']].reset_index()
    # filled=hold_df[hold_df['Hold Inactive Reason']=='FILLED'].reset_index()

    return {
        'data': [
            go.Scatter(
                x=filled['Date'],
                y=filled['Program Date'],
                mode='lines',
                name='Library Programs',
                line=dict(shape="spline", smoothing=1.3, width=3, color='green'),
                marker=dict(size=1, symbol='circle', color='white',
                            line=dict(color='orange', width=2)
                            ),

                hoverinfo='text',
                hovertext=
                '<b>Date</b>: ' + filled['Date'].astype(str) + '<br>' +
                # '<b>Type</b>: ' + filled['Hold Inactive Reason'].astype(str) + '<br>' +
                '<b>Programs</b>: ' + [f'{x:,.0f}' for x in filled['Program Date']] + '<br>'
            )
        ],

        
## --------------------
        'layout': go.Layout(
            # barmode = 'group',
             plot_bgcolor='#1f2c56',
             paper_bgcolor='#1f2c56',
             title={
                'text': 'Libray Programs Trend ',

                'y': 0.98,
                'x': 0.5,
                'xanchor': 'center',
                'yanchor': 'top'},
             titlefont={
                        'color': 'white',
                        'size': 20},

             hovermode='x',

             xaxis=dict(title='<b>Date</b>',
                        # tick0=0,
                        # dtick=1,
                        color='white',
                        showline=True,
                        showgrid=True,
                        linecolor='white',
                        linewidth=1,


                ),

             yaxis=dict(title='<b>Programs</b>',
                        color='white',
                        showline=False,
                        showgrid=True,
                        linecolor='white',

                ),

            legend = {
                'orientation': 'h',
                'bgcolor': '#1f2c56',
                'x': 0.5,
                'y': 1.25,
                'xanchor': 'center',
                'yanchor': 'top'},
            font = dict(
                family = "sans-serif",
                size = 12,
                color = 'white')


                 )

    }



