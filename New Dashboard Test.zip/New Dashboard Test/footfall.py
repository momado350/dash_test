#https://medium.com/innovation-res/how-to-build-an-app-using-dash-plotly-and-python-and-deploy-it-to-aws-5d8d2c7bd652
##http://patronActivitydash-env.eba-zv5vrzxh.us-east-2.elasticbeanstalk.com/
#https://www.youtube.com/watch?v=BeOKTpFsuvk

import dash
from dash import html
import dash_html_components as html
from dash import dcc
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import pandas as pd
# import dash_auth
# from users import USERNAME_PASSWORD_PAIRS
from app import app

mer_df = pd.read_csv('only 2023.csv',parse_dates=['Trans Hist Date'])
#mer_df = mer_df[mer_df['Trans Hist Date'] <= '2023-03-24']

covid_data_1 = mer_df.groupby(['Trans Hist Date'])[['patrons', 'SessionID', 'total']].sum().reset_index()
covid_data_1w = mer_df.groupby([pd.Grouper(key='Trans Hist Date', freq='W-SAT',label='left',closed='left')])[['patrons', 'SessionID', 'total']].sum().reset_index()
covid_data_1m = mer_df.groupby([pd.Grouper(key='Trans Hist Date', freq='M')])[['patrons', 'SessionID', 'total']].sum().reset_index()

# Traffic data ---------------------------------------------------------------------------
df = pd.read_csv('Traf-Sys.csv')
df['Date'] = pd.to_datetime(df['Date'])
traffic_data_1 = df.groupby(['Date'])[['Ins']].sum().reset_index()
traffic_data_1w = df.groupby([pd.Grouper(key='Date', freq='W-SAT',label='left',closed='left')])[['Ins']].sum().reset_index()
traffic_data_1m = df.groupby([pd.Grouper(key='Date', freq='M')])[['Ins']].sum().reset_index()


layout = html.Div([
    
    html.Div([
        html.Div([
            
        ], className='one-third column'),

        html.Div([
            html.Div([
                html.H3('footfall Dashboard', style={'margin-bottom': '0px', 'color': 'white'}),
                html.H5('Track footfall by Library Branch', style={'margin-bottom': '0px', 'color': 'white'})
            ])

        ], className='one-half column', id = 'title'),

        html.Div([
            html.H6('Last Updated: ' + str(df['Date'].iloc[-1].strftime('%B %d, %Y')) + ' 00:01 (UTC)',
                    style={'color': 'orange'})

        ], className='one-third column', id = 'title1'),

        html.Div([
            html.P('Select Year', className='fix_label', style= {'color': 'white'}),
            dcc.Slider(id = 'select_years',
                       included=False,
                       updatemode='drag',
                       tooltip={'always_visible': True},
                       min = 2022,
                       max = 2023,
                       step = 1,
                       value=2023,
                       marks={str(yr): str(yr) for yr in range(2022, 2023)},
                       className='dcc_compon'),

        ], className='one-half column', id = 'title2'),

    ], id = 'header', className= 'row flex-display', style={'margin-bottom': '25px'}),

    html.Div([
        html.Div([
            html.H6(children='Year-to-Date Traffic',
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{df['Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{traffic_data_1m['Ins'].sum():,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('Year before (Placeholder): ' + f"{0:,.0f}"
                   + ' (' + str(round(((0-traffic_data_1m['Ins'].sum()) /
                                   traffic_data_1m['Ins'].sum()) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})
            
        ], className='card_container three columns'),

html.Div([
            html.H6(children="Last Month Traffic",
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{df['Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{traffic_data_1m['Ins'].iloc[-2]:,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('Month Before: ' + f"{traffic_data_1m['Ins'].iloc[-3]:,.0f}"
                   + ' (' + str(round(((traffic_data_1m['Ins'].iloc[-2]-traffic_data_1m['Ins'].iloc[-3]) /
                                   traffic_data_1m['Ins'].iloc[-3]) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})

        ], className='card_container three columns'),

html.Div([
            html.H6(children="Month-to-Date Traffic",
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{df['Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{traffic_data_1m['Ins'].iloc[-1]:,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('How far from Last Month: ' + f"{traffic_data_1m['Ins'].iloc[-1]-traffic_data_1m['Ins'].iloc[-2]:,.0f}"
                   + ' (' + str(round(((traffic_data_1m['Ins'].iloc[-1]-traffic_data_1m['Ins'].iloc[-2]) / traffic_data_1m['Ins'].iloc[-2]) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})

        ], className='card_container three columns'),

html.Div([
            html.H6(children="Traffic Last Week",
                    style={'textAlign': 'center',
                           'color': 'white'}),
            html.P(f"{df['Date'].iloc[-1].strftime('%B %d, %Y')}",
            style={'textAlign': 'center',
                           'color': 'white',
                           'fontSize': 14}),
            html.P(f"{traffic_data_1w['Ins'].iloc[-1]:,.0f}",
                    style={'textAlign': 'center',
                           'color': 'orange',
                           'fontSize': 40}),
            html.P('Week Before: ' + f"{traffic_data_1w['Ins'].iloc[-2]:,.0f}"
                   + ' (' + str(round(((traffic_data_1w['Ins'].iloc[-1]-traffic_data_1w['Ins'].iloc[-2]) /
                                   traffic_data_1w['Ins'].iloc[-2]) * 100, 2)) + '%)',
                   style={'textAlign': 'center',
                          'color': 'orange',
                          'fontSize': 15,
                          'margin-top': '-18px'})

        ], className='card_container three columns'),

    ], className='row flex display'),
    
    html.Div([
        html.Div([
            html.P('Select Branch:', className='fix_label', style={'color': 'white'}),
            dcc.Dropdown(id = 'w_library',
                         multi = False,
                         searchable= True,
                         value='Central',
                         placeholder= 'Select Library',
                         options= [{'label': c, 'value': c}
                                   for c in (df['Branch Name'].unique())], className='dcc_compon'),
            html.P('Branch Traffic: ' + ' ' + str(df['Date'].iloc[-1].strftime('%B %d, %Y')),
                   className='fix_label', style={'text-align': 'center', 'color': 'white'}),
            dcc.Graph(id = 'confirmedtraffic', config={'displayModeBar': False}, className='dcc_compon',
                      style={'margin-top': '20px'}),
dcc.Graph(id = 'deathtraffic', config={'displayModeBar': False}, className='dcc_compon',
                      style={'margin-top': '20px'}),
dcc.Graph(id = 'recoveredtraffic', config={'displayModeBar': False}, className='dcc_compon',
                      style={'margin-top': '20px'}),
# dcc.Graph(id = 'active', config={'displayModeBar': False}, className='dcc_compon',
#                       style={'margin-top': '20px'})

        ], className='create_container three columns'),

        html.Div([
dcc.Graph(id = 'pie_charttraffic', config={'displayModeBar': 'hover'}
                      )
        ], className='create_container four columns'),

html.Div([
dcc.Graph(id = 'line_charttraffic', config={'displayModeBar': 'hover'}
                      )
        ], className='create_container five columns'),

    ], className='row flex-display'),

##########################################################################
    html.Div([
html.Div([
dcc.Graph(id = 'map_charttraffic', config={'displayModeBar': 'hover'}
                      )
        ], className='create_container1 twelve columns')

    ], className='row flex-display'),


], id = 'mainContainer', style={'display': 'flex', 'flex-direction': 'column'})


@app.callback(Output('confirmedtraffic', 'figure'),
              [Input('w_library','value')],
              [Input('select_years','value')])
def update_confirmed(w_library, select_years):
    traffic_data_1 = df.groupby(['Branch Name'])[['Ins']].sum().reset_index()
    value_confirmed = traffic_data_1[traffic_data_1['Branch Name'] == w_library]['Ins'].iloc[0]
    delta_confirmed = 0

    return {
        'data': [go.Indicator(
               mode='number+delta',
               value=value_confirmed,
               delta = {'reference': delta_confirmed,
                        'position': 'right',
                        'valueformat': ',i',
                        'relative': False,
                        'font': {'size': 15}},
               number={'valueformat': ',',
                       'font': {'size': 20}},
               domain={'y': [0, 1], 'x': [0, 1]}
        )],

        'layout': go.Layout(
            title={'text': 'Year-to-Date Traffic',
                   'y': 1,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            font=dict(color='orange'),
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            height = 50,

        )
    }

@app.callback(Output('deathtraffic', 'figure'),
              [Input('w_library','value')],
              [Input('select_years','value')])
def update_confirmed(w_library, select_years):
    mer_df_2 = df.groupby(['Branch Name', pd.Grouper(key='Date', freq='M',)])[['Ins']].sum().reset_index()
    value_death = mer_df_2[mer_df_2['Branch Name'] == w_library]['Ins'].iloc[-2]
    delta_death = mer_df_2[mer_df_2['Branch Name'] == w_library]['Ins'].iloc[-3]

    return {
        'data': [go.Indicator(
               mode='number+delta',
               value=value_death,
               delta = {'reference': delta_death,
                        'position': 'right',
                        'valueformat': ',i',
                        'relative': False,
                        'font': {'size': 15}},
               number={'valueformat': ',',
                       'font': {'size': 20}},
               domain={'y': [0, 1], 'x': [0, 1]}
        )],

        'layout': go.Layout(
            title={'text': 'Traffic Last Month',
                   'y': 1,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            font=dict(color='orange'),
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            height = 50,

        )
    }





@app.callback(Output('recoveredtraffic', 'figure'),
              [Input('w_library','value')],
              [Input('select_years','value')])
def update_confirmed(w_library, select_years):
    covid_data_2 = df.groupby(['Branch Name', pd.Grouper(key='Date', freq='W-SAT',label='left',closed='left')])[['Ins']].sum().reset_index()
    value_recovered = covid_data_2[covid_data_2['Branch Name'] == w_library]['Ins'].iloc[-2]
    delta_recovered = covid_data_2[covid_data_2['Branch Name'] == w_library]['Ins'].iloc[-3]

    return {
        'data': [go.Indicator(
               mode='number+delta',
               value=value_recovered,
               delta = {'reference': delta_recovered,
                        'position': 'right',
                        'valueformat': ',i',
                        'relative': False,
                        'font': {'size': 15}},
               number={'valueformat': ',',
                       'font': {'size': 20}},
               domain={'y': [0, 1], 'x': [0, 1]}
        )],

        'layout': go.Layout(
            title={'text': 'Traffic Last Week',
                   'y': 1,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            font=dict(color='orange'),
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            height = 50,

        )
    }






@app.callback(Output('pie_charttraffic', 'figure'),
              [Input('w_library','value')],
              [Input('select_years','value')])
def update_graph(w_library,select_years):
    traffic_data_11 = df.groupby(['Branch Name'])[['Ins']].sum().reset_index()
    confirmed_value = traffic_data_11[traffic_data_11['Branch Name'] == w_library]['Ins'].iloc[0]
    death_value = traffic_data_11[traffic_data_11['Branch Name'] != w_library]['Ins'].sum()
    recovered_value = confirmed_value + death_value
    colors = ['orange', 'blue']

    return {
        'data': [go.Pie(
            # labels=['Circulation', 'Computer', 'Total of Both'],
            labels=['Selected Branch', 'All other Branches'],
            values=[confirmed_value, death_value, recovered_value],
            marker=dict(colors=colors),
            hoverinfo='label+value+percent',
            textinfo='label+value+percent',
            hole=.7,
            rotation=45,
            # insidetextorientation= 'radial'

        )],

        'layout': go.Layout(
            title={'text': 'Branch Year-to-Date to Library Total: ' + (w_library),
                   'y': 0.93,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            titlefont={'color': 'white',
                       'size': 20},
            font=dict(family='sans-serif',
                      color='white',
                      size=12),
            hovermode='closest',
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            legend={'orientation': 'h',
                    'bgcolor': '#1f2c56',
                    'xanchor': 'center', 'x': 0.5, 'y': -0.7}


        )
    }

@app.callback(Output('line_charttraffic', 'figure'),
              [Input('w_library','value')],
              [Input('select_years','value')])
def update_graph(w_library, select_years):
    covid_data_2 = df.groupby(['Branch Name','Date'])['Ins'].sum().reset_index()
    covid_data_21 = covid_data_2[covid_data_2['Branch Name'] == w_library][['Branch Name', 'Date', 'Ins']].reset_index()
    covid_data_21['daily confirmed'] = covid_data_21['Ins'].shift(0)
    covid_data_21['Rolling Ave.'] = covid_data_21['Ins'].rolling(window=7).mean()


    return {
        'data': [go.Bar(
            x=covid_data_21['Date'].tail(30),
            y=covid_data_21['daily confirmed'].tail(30),
            name='Daily Patron Traffic',
            marker=dict(color='orange'),
            hoverinfo='text',
            hovertext=
            '<b>Date</b>: ' + covid_data_21['Date'].tail(30).astype(str) + '<br>' +
            '<b>Daily Traffic Numbers</b>: ' + [f'{x:,.0f}' for x in covid_data_21['daily confirmed'].tail(30)] + '<br>' +
            '<b>Branch</b>: ' + covid_data_21['Branch Name'].tail(30).astype(str) + '<br>'


        ),
            go.Scatter(
                x=covid_data_21['Date'].tail(30),
                y=covid_data_21['Rolling Ave.'].tail(30),
                mode='lines',
                name='Rolling Average of the last 7 days - daily Patron Traffic',
                line=dict(width=3, color='#FF00FF'),
                hoverinfo='text',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['Date'].tail(30).astype(str) + '<br>' +
                '<b>Daily Traffic</b>: ' + [f'{x:,.0f}' for x in covid_data_21['Rolling Ave.'].tail(30)] + '<br>'


            )],

        'layout': go.Layout(
            title={'text': 'Last 30 Days Daily Patron Traffic at ' + (w_library),
                   'y': 0.93,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            titlefont={'color': 'white',
                       'size': 20},
            font=dict(family='sans-serif',
                      color='white',
                      size=12),
            hovermode='closest',
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            legend={'orientation': 'h',
                    'bgcolor': '#1f2c56',
                    'xanchor': 'center', 'x': 0.5, 'y': -0.7},
            margin=dict(r=0),
            xaxis=dict(title='<b>Date</b>',
                       color = 'white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Aerial',
                           color='white',
                           size=12
                       )),
            yaxis=dict(title='<b>Daily Patron Traffic</b>',
                       color='white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Aerial',
                           color='white',
                           size=12
                       )
                       )


        )
    }

@app.callback(Output('map_charttraffic', 'figure'),
              [Input('w_library','value')],
              [Input('select_years','value')])
def update_graph(w_library,select_years):
    df['hour'] = pd.to_datetime(df['HourEnding'].astype(str), format='%H').dt.strftime('%I %p')
    hours = df[(df['HourEnding'] >= 9) & (df['HourEnding'] <= 20)]
    covid_data_21 = hours.groupby(['Branch Name','Date', 'hour'])['Ins'].sum().reset_index()
    covid_data_21 = covid_data_21[covid_data_21['Branch Name'] == w_library][['Branch Name', 'Date','hour', 'Ins']].reset_index()
    covid_data_21 = pd.pivot_table(covid_data_21, columns='hour', values='Ins', index='Date').fillna(0).round(decimals = 0)
    cols = {'date':'2023-20-02 00:00:00','01 PM':[0], '10 AM':[0], '11 AM':[0], '12 PM':[0], '02 PM':[0], '03 PM':[0], '04 PM':[0], '05 PM':[0],
     '06 PM':[0], '07 PM':[0], '08 PM':[0], '09 AM':[0]}
    empty = pd.DataFrame(data=cols).set_index("date")

    covid_data_21 = empty.append(covid_data_21, ignore_index=False).drop_duplicates().reset_index().fillna(0)


    return {
        'data': [go.Scatter(
            x=covid_data_21['index'],
            y=covid_data_21['09 AM'],
            name='9 AM',
            marker=dict(color='orange'),
            hoverinfo='text',
            visible='legendonly',
            hovertext=
            '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
            '<b>Daily Traffic</b>: ' + [f'{x:,.0f}' for x in covid_data_21['09 AM']] + '<br>' 
            + '<b>Hour</b>: ' + '9 AM' + '<br>'


        ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['10 AM'],
                mode='lines',
                name='10 AM',
                line=dict(width=3, color='#FF00FF'),
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Traffic</b>: ' + [f'{x:,.0f}' for x in covid_data_21['10 AM']] + '<br>' 
                + '<b>Hour</b>: ' + '10 AM' + '<br>'


            ),
                go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['11 AM'],
                mode='lines',
                name='11 AM',
                line=dict(width=3, color='red'),
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Traffic</b>: ' + [f'{x:,.0f}' for x in covid_data_21['11 AM']] + '<br>'
                + '<b>Hour</b>: ' + '11 AM' + '<br>'


            ),
                go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['12 PM'],
                mode='lines',
                name='12 PM',
                line=dict(width=3, color='green'),
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Traffic</b>: ' + [f'{x:,.0f}' for x in covid_data_21['12 PM']] + '<br>'
                + '<b>Hour</b>: ' + '12 AM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['01 PM'],
                mode='lines',
                name='1 PM',
                line=dict(width=3, color='#000000'),
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Traffic</b>: ' + [f'{x:,.0f}' for x in covid_data_21['01 PM']] + '<br>'
                + '<b>Hour</b>: ' + '1 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['02 PM'],
                mode='lines',
                name='2 PM',
                line=dict(width=3, color='#00FF00'),
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Traffic</b>: ' + [f'{x:,.0f}' for x in covid_data_21['02 PM']] + '<br>'
                + '<b>Hour</b>: ' + '2 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['03 PM'],
                mode='lines',
                name='3 PM',
                line=dict(width=3, color='#00FFFF'), #cyan
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Traffic</b>: ' + [f'{x:,.0f}' for x in covid_data_21['03 PM']] + '<br>'
                + '<b>Hour</b>: ' + '3 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['04 PM'],
                mode='lines',
                name='4 PM',
                line=dict(width=3, color='#008080'), #teal
                hoverinfo='text',
                #visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Traffic</b>: ' + [f'{x:,.0f}' for x in covid_data_21['04 PM']] + '<br>'
                + '<b>Hour</b>: ' + '4 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['05 PM'],
                mode='lines',
                name='5 PM',
                line=dict(width=3, color='#000080'), #navy
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Traffic</b>: ' + [f'{x:,.0f}' for x in covid_data_21['05 PM']] + '<br>'
                + '<b>Hour</b>: ' + '5 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['06 PM'],
                mode='lines',
                name='6 PM',
                line=dict(width=3, color='#A52A2A'),#brown
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Traffic</b>: ' + [f'{x:,.0f}' for x in covid_data_21['06 PM']] + '<br>'
                + '<b>Hour</b>: ' + '6 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['07 PM'],
                mode='lines',
                name='7 PM',
                line=dict(width=3, color='#FF7F50'),#coral
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Traffic</b>: ' + [f'{x:,.0f}' for x in covid_data_21['07 PM']] + '<br>'
                + '<b>Hour</b>: ' + '7 PM' + '<br>'


            ),
            go.Scatter(
                x=covid_data_21['index'],
                y=covid_data_21['08 PM'],
                mode='lines',
                name='8 PM',
                line=dict(width=3, color='#FFD700'),#gold
                hoverinfo='text',
                visible='legendonly',
                hovertext=
                '<b>Date</b>: ' + covid_data_21['index'].astype(str) + '<br>' +
                '<b>Daily Traffic</b>: ' + [f'{x:,.0f}' for x in covid_data_21['08 PM']] + '<br>'
                + '<b>Hour</b>: ' + '8 PM' + '<br>'


            )
            
            ],

        'layout': go.Layout(
            title={'text': 'Year to date Daily Patron Traffic at ' + (w_library),
                   'y': 0.93,
                   'x': 0.5,
                   'xanchor': 'center',
                   'yanchor': 'top'},
            titlefont={'color': 'white',
                       'size': 20},
            font=dict(family='sans-serif',
                      color='white',
                      size=12),
            hovermode='closest',
            paper_bgcolor='#1f2c56',
            plot_bgcolor='#1f2c56',
            legend={'orientation': 'h',
                    'bgcolor': '#1f2c56',
                    'xanchor': 'center', 'x': 0.5, 'y': -0.7},
            margin=dict(r=0),
            xaxis=dict(title='<b>Date</b>',
                       color = 'white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Aerial',
                           color='white',
                           size=12
                       )),
            yaxis=dict(title='<b>Daily Patron Traffic</b>',
                       color='white',
                       showline=True,
                       showgrid=True,
                       showticklabels=True,
                       linecolor='white',
                       linewidth=1,
                       ticks='outside',
                       tickfont=dict(
                           family='Aerial',
                           color='white',
                           size=12
                       )
                       )


        )
    }
    ##
# @app.callback(Output('map_chart1traffic', 'figure'),
#               [Input('w_library1','value')],
#               [Input('select_years','value')])
# def update_graph(w_library1,select_years):
#     circulationjcb_3 = circulationjcb.groupby(['Trans Stat Station Library','Trans Stat Date', 'Trans Stat Itype', 'year'])['Trans Stat Id'].count().reset_index()
#     both = circulationjcb_3[(circulationjcb_3['Trans Stat Station Library'] == w_library1) & (circulationjcb_3['year'] == select_years)][['Trans Stat Itype','Trans Stat Station Library', 'Trans Stat Date', 'Trans Stat Id']]#.reset_index()
#     chromebook = both[both['Trans Stat Itype'] == 'EQ-ECFCB']
#     hotspot = both[both['Trans Stat Itype'] == 'EQ-ECFHOT']
    
    

#     return {
#         'data': [go.Scatter(
#             x=chromebook['Trans Stat Date'],
#             y=chromebook['Trans Stat Id'],
#             mode='lines',
#             name='Chromebooks',
#             marker=dict(color='orange'),
#             hoverinfo='text',
#             hovertext=
#             '<b>Date</b>: ' + chromebook['Trans Stat Date'].astype(str) + '<br>' +
#             '<b>Daily Chromebook Numbers</b>: ' + [f'{x:,.0f}' for x in chromebook['Trans Stat Id']] + '<br>' 
#             #+ '<b>Hour</b>: ' + '9 AM' + '<br>'


#         ),
#         go.Scatter(
#             x=hotspot['Trans Stat Date'],
#             y=hotspot['Trans Stat Id'],
#             mode='lines',
#             name='ECF-Hotspots',
#             marker=dict(color='blue'),
#             hoverinfo='text',
#             hovertext=
#             '<b>Date</b>: ' + hotspot['Trans Stat Date'].astype(str) + '<br>' +
#             '<b>Daily Hotspots Numbers</b>: ' + [f'{x:,.0f}' for x in hotspot['Trans Stat Id']] + '<br>'


#         )
#         ],

#         'layout': go.Layout(
#             # title={'text': 'Year to date Daily Patron Activity: ' + (w_library),
#             title={'text': 'Year to date Daily ECF-Chromebooks and ECF-Hotspots checkouts: ' + (w_library1),
#                    'y': 0.93,
#                    'x': 0.5,
#                    'xanchor': 'center',
#                    'yanchor': 'top'},
#             titlefont={'color': 'white',
#                        'size': 20},
#             font=dict(family='sans-serif',
#                       color='white',
#                       size=12),
#             hovermode='closest',
#             paper_bgcolor='#1f2c56',
#             plot_bgcolor='#1f2c56',
#             legend={'orientation': 'h',
#                     'bgcolor': '#1f2c56',
#                     'xanchor': 'center', 'x': 0.5, 'y': -0.7},
#             margin=dict(r=0),
#             xaxis=dict(title='<b>Date</b>',
#                        color = 'white',
#                        showline=True,
#                        showgrid=True,
#                        showticklabels=True,
#                        linecolor='white',
#                        linewidth=1,
#                        ticks='outside',
#                        tickfont=dict(
#                            family='Aerial',
#                            color='white',
#                            size=12
#                        )),
#             yaxis=dict(title='<b>Daily Chromebook</b>',
#                        color='white',
#                        showline=True,
#                        showgrid=True,
#                        showticklabels=True,
#                        linecolor='white',
#                        linewidth=1,
#                        ticks='outside',
#                        tickfont=dict(
#                            family='Aerial',
#                            color='white',
#                            size=12
#                        )
#                        )


#         )
#     }
    
